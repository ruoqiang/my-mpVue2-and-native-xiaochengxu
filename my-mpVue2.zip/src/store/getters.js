
// export const token = state => state.token

export const userApplyStep = state => state.userApplyStep
