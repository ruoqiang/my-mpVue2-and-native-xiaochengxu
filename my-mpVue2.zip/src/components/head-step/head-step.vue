<template>
  <div id="head-step">
    <div class="head-setp">
        <div class="setp">
          <div class="setp-tips-box">
            <span :class="{active:step>index}" v-for="(item,index) in stepText">{{item}}</span>
          </div>
          <div class="setp-dot-box">
            <span :class="[{'active':index<=step+(step-1)},{'setp-line':index%2===1}]" v-for="(item,index) in stepLine"></span>
            <!-- <span class="setp-line"></span>
              <span class=""></span>
            <span class="setp-line"></span>
              <span class=""></span>
            <span class="setp-line"></span>
            <span class=""></span> -->
          </div>
        </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "head-step",
  props: {
    step: {
      type: Number,
      default: 1
    }
  },
  data: () => ({
    stepText: ['申请人信息', '车辆信息', '证件照片', '收货地址'],
    stepLine: ['1', '2', '3', '4', '5', '6', '7']
  }),
  methods: {
    methodName() {
      //
    }
  },
  computed: {
    // stepType() {
    //   return
    // }
  }
}
</script>
<style lang="stylus" scoped>
.setp-tips-box {
    padding-top: 25px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 84%;
    margin: 0 auto;
    -webkit-box-pack: justify;
        -ms-flex-pack: justify;
            justify-content: space-between;
  }
  .setp-tips-box span {
    width: 75px;
    height: 21px;
    text-align: center;
    line-height: 21px;
    color: #999;
    font-size: 13px;
    display: inline-block;
    color: #999;
  }
  .setp-tips-box span.active {
    color: #2d4ed1;
    position: relative;
  }
  .setp-tips-box input::-webkit-input-placeholder {
    text-shadow: none;
    -webkit-text-fill-color: initial;
    -webkit-user-select: auto !important;
  }
  .setp-dot-box {
    width: 67%;
    margin: 0 auto;
    -webkit-box-pack: justify;
        -ms-flex-pack: justify;
            justify-content: space-between;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    margin-top: 10px;
  }
  .setp-dot-box span {
    width: 14px;
    height: 14px;
    background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzZCRUJCODNFQTE2MTFFNzlERTI5Q0U5QTM0ODVCQUQiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzZCRUJCODJFQTE2MTFFNzlERTI5Q0U5QTM0ODVCQUQiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpENTYzQUI3RERDQzAxMUU3QUQ0NUFDOTU3QTQxN0ZDRCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpENTYzQUI3RURDQzAxMUU3QUQ0NUFDOTU3QTQxN0ZDRCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PsQHOF0AAAFtSURBVHjavJa7SgNBFIZPBgtJmbyDt0ZhiyCiQQstUih5hYCmNL2pzANoqXkGRZuAFkFJCAR2wTTe3mHbaJf8B87CuJpxd7OzP3wEdjPnY5jZM5NzXZf+yRI4AvtgDRTluQ9ewSO4cxzn01QkZxCVwTnYpmjpgSaEz1FFi+ACHPN7ipcJuAanEH7rL1TojwXQBScJJCRjeGzX87zCLFEedMAmzR+u0YEs/5foEpQovZSk5g8RL3yN0k8NsyrrolbCNYmyZq1g163j94XsZoNnVCX7qaoYH+Q82WHRSgaiZaX1LpspKsooSrqw7fgses9A9KGkvdtOj0W3GYhuWDQCfYuSPs6mUbDrzuTQSjtcs6k3VT5+2xZEbczmKXweNcAwRclQav46+MagkpKMa1Qwm/GsOwN/vLvgKuGaTWTsHiS+6XLC+QJ1EQ5iSAYiqOszCbJgGMgbZEu6+yE4AKuhC+QbeAD3KG7sMFMBBgCLzFQW/3tj+QAAAABJRU5ErkJggg==');
    background-size: 100% 100%;
    display: inline-block;
    position: relative;
  }
  .setp-dot-box span.active {
    background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAAXNSR0IArs4c6QAAAsBJREFUSA21Vk1oU0EQntmkLbRCTUQPrUZppLVIEosUBEG01IIebMSD4NWLRA+KEAqK9GBABMWDFS969Ca2HhWiIIKgUpKAf1As0daDYFERidas+22yYfNek+bF+C47O7PzfW92Z3aWaZUvdvh1f1H+jpOk/UwyJIl74KLkRSXnlfBQcNt05t7gu3pQXMsYiWd3clFelkQjtdbYegWUloKTuenoS1tvZBfR3knpX5rNXStKShBJl904rjyy4qIbgaHI6ceTvGyvqQKKHMsG+Ie8KyXtsxd5lZnpkeziI7k70SXjK4yASFpBAjz8KLCAafArRNiuf43EgBoyYBqd3jocPBXpufczMTC1RpYkaBgJoiNCdrWeRMfFJWwiET2UGWg0hWv9N/Trg366dbGPNve0Vy0DNmpRqHwcr7I0MQHJ7VSYhiNr6EJiowsBBS9Q8S6LB0UpkrCKpIPmFwo0cTXv9lYcqr5kyG1pTGNItvSWSI6fn6PPX6rqVAOBQ5i7y4b2qRSJjwZslUtulASO4KgUlI2UOrOJDu4J0PatnZS6uWCbtOyFpOyMq0kuOpHSz77R8h9JRw+so3MneqvMTZDgpv/k27Atgazrs9HmPhTo/ccCjezqpmh/JwXX+unJi+/lFA7TamdiY2mZedaPfqI2cdRpfPD0q1Ll6dLZkI6so41px2CXdxIAKw4uF+wbJ5GZj+3u1mR+X+miRwrXyi7j4xyFr31AZO/H3iqItNNo5ohs4kpen1kzJMBG99VZp1IiWe9SBVnh1zy9mvu5Yp2Yn3KPLKWgJPSl/VBCbDx7vSjlSffi5jWCeSozEz0FBH17Q0D7RWeE3IoPWMA0WBUi9Hi031aQmVZuvxsqRGBGjw8ORccQstpVdcN7/fA44Slg2O8FoFTOyAn5359bTkJdZ+hZdR6QqovOoEycvvb8L9GqOJCzDvZNAAAAAElFTkSuQmCC');
    position: relative;
    background-size: 100% 100%;
  }

  .setp-dot-box span.setp-line {
    height: 1px;
    width: 45px;
    margin-top: 10px;
    position: relative;
    background: none;
  }
  .setp-line:after {
    display: block;
    position: absolute;
    left: 0px;
    bottom: 4px;
    content: " ";
    width: 100%;
    border-top: 1px solid #ccc;
  }
  .setp {
    height: 93px;
    width: 100%;
  }
</style>
