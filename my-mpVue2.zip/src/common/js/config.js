export const playMode = {
  sequence: 0,
  loop: 1,
  random: 2
}

export const noToken =  11111
