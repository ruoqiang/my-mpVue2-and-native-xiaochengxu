<template>
  <div class="userBaseinfo">
    userBaseinfo
  </div>
</template>
<script>

export default {

}
</script>

<style lang="stylus">

</style>
