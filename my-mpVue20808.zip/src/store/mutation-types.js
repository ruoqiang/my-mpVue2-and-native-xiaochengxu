// export const SET_SEARCH_HISTORY = 'SET_SEARCH_HISTORY'
//
// export const SET_PLAY_HISTORY = 'SET_PLAY_HISTORY'
//
// export const SET_FAVORITE_LIST = 'SET_FAVORITE_LIST'
//
// export const SET_TOKEN = 'SET_TOKEN'

export const SET_USER_APPLY_STEP = 'SET_USER_APPLY_STEP'
